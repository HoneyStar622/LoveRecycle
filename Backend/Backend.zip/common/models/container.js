'use strict';

module.exports = function(Picture) {

};
